package com.example.cross.setgame;
import org.json.JSONException;
import org.json.JSONObject;
class Card {
    int count, fill, shape, color;
    public Card(int count, int fill, int shape, int color) {
        this.count = count; this.fill = fill; this.shape = shape; this.color = color;
    }
    static int getThirdInt(int i, int j) {
        if (i == j)
            return i;
        return 6 - (i+j);
    }
    static Card getThird(Card a, Card b){
        return new Card(getThirdInt(a.count, b.count),
                getThirdInt(a.fill, b.fill),
                getThirdInt(a.shape, b.shape),
                getThirdInt(a.color, b.color)
        );

    }
    public JSONObject toJSON() {
        JSONObject j = new JSONObject();


        try {
            j.put("color", color);
            j.put("fill", fill);
            j.put("shape", shape);
            j.put("count", count);
        } catch (JSONException e) {

        }
        return j;

    }

    @Override
    public String toString() {
        return "[ " +
                "count=" + count +
                ", fill=" + fill +
                ", shape=" + shape +
                ", color=" + color +
                ']';
    }
    @Override
    public boolean equals(Object o) {

        if (o == null)
            return false;
        Card card = (Card) o;
        if (count != card.count) return false;
        if (fill != card.fill) return false;
        if (shape != card.shape) return false;
        return color == card.color;

    }

    @Override
    public int hashCode() {
        int result = count;
        result = 31 * result + fill;
        result = 31 * result + shape;
        result = 31 * result + color;
        return result;
    }
}