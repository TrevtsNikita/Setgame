package com.example.cross.setgame;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    int token;
    ListView listView;
    final ArrayList<Card> cards = new ArrayList<Card>();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        token = intent.getIntExtra("token", 0);
        listView = (ListView)findViewById(R.id.listView);

        MyThread mt = new MyThread(token);
        mt.start();
        try {
            mt.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        final ArrayAdapter<Card> adapter;
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cards);
        listView.setAdapter(adapter);
    }

    public class MyThread extends Thread {

        int token;
        public MyThread(int token) {
            super();
            this.token = token;
        }

        @Override
        public void run() {

            URL url = null;
            try {
                url = new URL("http://194.176.114.21:8050");
                String reg = "{\"action\" : \"fetch_cards\", \"token\" : "+ token +" }";

                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setDoOutput(true);
                OutputStream out = urlConnection.getOutputStream();
                out.write(reg.getBytes());
                Scanner in = new Scanner(urlConnection.getInputStream());

                if (in.hasNext()) {

                    String response = in.nextLine();
                    JSONObject resp = new JSONObject(response);
                    JSONArray cards1 = resp.getJSONArray("cards");

                    for (int k = 0; k < cards1.length(); k++) {
                        JSONObject c = cards1.getJSONObject(k);
                        int count = c.getInt("count");
                        int color = c.getInt("color");
                        int shape = c.getInt("shape");
                        int fill = c.getInt("fill");
                        cards.add(new Card(count, fill, shape, color));
                    }
                }

                in.close();
                urlConnection.disconnect();

            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }

}