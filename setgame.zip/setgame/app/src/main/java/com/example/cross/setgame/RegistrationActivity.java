package com.example.cross.setgame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class RegistrationActivity extends AppCompatActivity {

    EditText Login;
    Button btnReg;
    TextView Error;
    int token = 0;

    public class MyThread extends Thread {
        EditText Login;
        TextView Error;
        String login;
        int token;

        public MyThread(EditText editText, TextView textView, int token) {
            super();
            this.Login = editText;
            this.Error = textView;
            this.token = token;
        }

        @Override
        public void run() {
            login = String.valueOf(Login.getText());
            if (token == 0) {
                token = signUp();
            }
        }

        public int signUp() {

            URL url = null;
            try {
                url = new URL("http://194.176.114.21:8050");
                String reg = "{ \"action\": \"register\", \"nickname\": \"" + login + "\"}";
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setDoOutput(true);
                OutputStream out = urlConnection.getOutputStream();
                out.write(reg.getBytes());
                Scanner in = new Scanner(urlConnection.getInputStream());
                if (in.hasNext()) {
                    String response = in.nextLine();
                    JSONObject resp = new JSONObject(response);
                    if (resp.getInt("token") == -1) {
                        Error.setText("Ошибка: Это имя уже существует!");
                        return 0;
                    }
                    Log.d("Answer", String.valueOf(resp.getInt("token")));
                    return resp.getInt("token");
                }
                in.close();
                urlConnection.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Error.setText("Error: ??? ");
            return 0;
        }
        public int getToken() {
            return this.token;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        btnReg = (Button) findViewById(R.id.btnReg);
        Login = (EditText) findViewById(R.id.Login);
        Error = (TextView) findViewById(R.id.Error);
    }

    public void onClickReg(View view) throws InterruptedException {
        MyThread mt = new MyThread(Login, Error, token);
        mt.start();
        mt.join();
        token = mt.token;
        Log.d("token", String.valueOf(token));
        if (token != 0 && token != -1) {
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra("token", token);
            startActivity(i);
        }
    }
}